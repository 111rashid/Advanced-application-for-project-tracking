let reports = [];
let isArabic = false;

// تغيير اللغة
function toggleLanguage() {
    isArabic = !isArabic;
    if (isArabic) {
        document.getElementById("appTitle").innerText = "تطبيق متابعة المشروع";
        document.querySelector("h2").innerText = "التقارير والتقدم";
        document.querySelector("button").innerText = "تغيير اللغة";
    } else {
        document.getElementById("appTitle").innerText = "Project Tracking Application";
        document.querySelector("h2").innerText = "Reports & Progress";
        document.querySelector("button").innerText = "Change Language";
    }
}

// تغيير لون الخلفية
function changeBackgroundColor() {
    const colors = ["#f5f5f5", "#e0f7fa", "#f1f8e9", "#ffebee", "#fff3e0"];
    document.body.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
}

// حفظ البيانات المدخلة
function saveData() {
    const member = document.getElementById('memberSelect').value;
    const date = document.getElementById('date').value;
    const engineerName = document.getElementById('engineerName').value;
    const stage = document.getElementById('stage').value;
    const reportText = document.getElementById('reportText').value;
    const progressPercentage = document.getElementById('progressPercentage').value;
    const images = document.getElementById('imageUpload').files;

    // تخزين البيانات في مصفوفة التقارير
    const reportData = {
        member,
        date,
        engineerName,
        stage,
        reportText,
        progressPercentage,
        images: Array.from(images)
    };

    reports.push(reportData);

    displayReports();
}

// عرض التقارير في الجزء الأول
function displayReports() {
    const reportList = document.getElementById('reportList');
    reportList.innerHTML = '';

    reports.forEach(report => {
        const reportItem = document.createElement('div');
        reportItem.classList.add('report-item');

        let imageHtml = '';
        report.images.forEach(image => {
            const imageUrl = URL.createObjectURL(image);
            imageHtml += `<img src="${imageUrl}" alt="Uploaded Image" class="image-preview">`;
        });

        reportItem.innerHTML = `
            <p><strong>Member:</strong> ${report.member}</p>
            <p><strong>Engineer:</strong> ${report.engineerName}</p>
            <p><strong>Stage:</strong> ${report.stage}</p>
            <p><strong>Date:</strong> ${report.date}</p>
            <p><strong>Report:</strong> ${report.reportText}</p>
            <p><strong>Progress:</strong> ${report.progressPercentage}%</p>
            <p><strong>Images:</strong> ${imageHtml}</p>
        `;
        reportList.appendChild(reportItem);
    });
}

// مشاركة البيانات عبر WhatsApp
function shareData() {
    const report = encodeURIComponent(JSON.stringify(reports));
    const url = `https://wa.me/?text=${report}`;
    window.open(url, '_blank');
}

// مشاركة البيانات عبر Email
function emailData() {
    const report = encodeURIComponent(JSON.stringify(reports));
    const subject = "Project Tracking Data";
    const body = `Here are the project tracking details:\n\n${report}`;
    window.location.href = `mailto:?subject=${subject}&body=${body}`;
}
